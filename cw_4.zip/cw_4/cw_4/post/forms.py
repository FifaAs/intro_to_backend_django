from django import forms
from .models import Thread, Post

class ThreadForm(forms.ModelForm):
    class Meta:
        model = Thread
        fields = ['name', 'description']

class PostForm(forms.ModelForm):
    picture = forms.FileField(required=False)
    class Meta:
        model = Post
        fields = ['title', 'picture', 'description', 'author']