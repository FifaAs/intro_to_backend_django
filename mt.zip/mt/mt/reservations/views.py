from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
from django.contrib import messages
from .models import Reservation
from customers.models import Customer
from tables.models import Table
from django.utils.dateparse import parse_date

# 7. Создание брони (проверяем, чтобы у пользователя не было брони на этот день)
def create_reservation(request):
    if request.method == "POST":
        customer_id = request.POST.get('customer')
        table_id = request.POST.get('table')
        date = request.POST.get('date')

        # Преобразование в число (если возможно)
        try:
            customer_id = int(customer_id)
            table_id = int(table_id)
        except (TypeError, ValueError):
            messages.error(request, "Некорректные данные клиента или столика.")
            return redirect('create_reservation')

        customer = get_object_or_404(Customer, id=customer_id)
        table = get_object_or_404(Table, id=table_id)

        # Проверяем, есть ли у пользователя бронь на этот день
        existing_reservation = Reservation.objects.filter(customer=customer, date=date).exists()
        if existing_reservation:
            messages.error(request, "У вас уже есть бронь на этот день.")
            return redirect('create_reservation')

        # Проверяем, не занята ли бронь другим пользователем
        if Reservation.objects.filter(table=table, date=date).exists():
            messages.error(request, "Этот столик уже зарезервирован.")
            return redirect('create_reservation')

        reservation = Reservation.objects.create(customer=customer, table=table, date=date, status="pending")
        messages.success(request, "Бронь успешно создана!")
        return redirect('reservation_detail', id=reservation.id)

    customers = Customer.objects.all()
    tables = Table.objects.all()
    return render(request, 'reservations/create_reservation.html', {'customers': customers, 'tables': tables})


# 8. Получение деталей брони
def reservation_detail(request, id):
    reservation = get_object_or_404(Reservation, id=id)
    return render(request, 'reservations/reservation_detail.html', {'reservation': reservation})


# 9. Список всех броней пользователя
def user_reservations(request, user_id):
    reservations = Reservation.objects.filter(customer__id=user_id)
    return render(request, 'reservations/user_reservations.html', {'reservations': reservations})


# 10. Обновление статуса брони
def update_reservation_status(request, id):
    reservation = get_object_or_404(Reservation, id=id)
    if request.method == "POST":
        new_status = request.POST.get('status')
        if new_status in ["pending", "confirmed", "canceled"]:
            reservation.status = new_status
            reservation.save()
            messages.success(request, "Статус брони обновлен.")
        else:
            messages.error(request, "Некорректный статус.")
        return redirect('reservation_detail', id=id)
    return render(request, 'reservations/update_reservation.html', {'reservation': reservation})


# 11. Удаление брони
def delete_reservation(request, id):
    reservation = get_object_or_404(Reservation, id=id)
    reservation.delete()
    messages.success(request, "Бронь удалена.")
    return redirect('user_reservations', user_id=reservation.customer.id)
